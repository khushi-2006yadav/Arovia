# Arovia Frontend — Current Backend Mapping

This frontend is aligned to the backend in `Arovia-main` without changing backend code.

## Auth

- `POST /api/signup` -> normal signup. Backend returns no body; frontend redirects to login.
- `POST /api/signin` -> returns `UserResponseDto` including `userId` and `jwt`.
- `POST /api/oauth-signin` -> sends `{ token: <JWT> }` and stores the returned JWT/user context.
- `POST /api/oauth-signup` -> sends the Google JWT plus the health-profile fields and stores the returned `UserResponseDto`.
- Google button now starts the backend Spring Security flow at `/oauth2/authorization/google`.
- Backend redirects to `/oauth-success?token=<JWT>`; `OAuthSuccess.jsx` extracts the JWT, calls `/api/oauth-signin`, stores the user context, and routes incomplete profiles to `/signup/complete`.

## User context / userId

`AuthContext` is the single source of truth for the signed-in user. It exposes:

- `user`
- `userId`
- `emailId`
- `token`
- `isAuthenticated`

All user-scoped record calls take `userId` from this context. The OAuth JWT's subject/email is handled by the backend's `JWTService`; the frontend does not need to send the email separately for OAuth calls.

## Records

The current backend exposes all three record operations, so the frontend no longer keeps a fake local record-id index:

- `POST /api/record/{userId}/addRecords` -> creates a record and returns its id.
- `GET /api/record/fetchRecord/{recordId}` -> loads one complete `MedicalRecord`.
- `GET /api/record/fetchRecords/{userId}` -> loads the user's complete record list.

The Records, Timeline, Dashboard, Insights, and Medicines pages all use the real list endpoint.

`MedicalRecordDto` is mapped exactly to the backend fields: `recordType`, `recordDate`, `title`, `diagnoses`, `testResults`, `medications`, `doctor`, `observations`, and `additionalDetails`.

## Medicines

The current backend does **not** expose a medicine-fetch/alternatives endpoint. Medicine information is therefore taken from the nested `medicine` object already returned inside each `MedicalRecord.medications` entry.

The frontend does not fabricate a medicine database, fake alternatives, local discontinued status, or local side-effect records anymore.

The one currently usable medicine action is the backend redirect:

- `GET /api/medication/nearest-pharmacy?location=...`

## AI / image upload

The current backend exposes:

- `POST /api/ai/uploadRecord`
- `POST /api/ai/fetchHealthSuggestion`

However, the current `uploadRecord` controller declares `@RequestBody java.awt.Image`. That is not a browser file-upload contract (no `MultipartFile`, no multipart endpoint, and no documented JSON/base64 DTO), so the frontend can select an image but cannot truthfully send a browser image to that endpoint without changing the backend signature.

Likewise, the current `fetchHealthSuggestion` controller does not declare `@RequestBody` for `HealthSnapshot`, so a JSON body is not a reliable contract for this endpoint.

The frontend therefore does **not** pretend these AI calls are working. Record trends and status summaries are calculated only from data already returned by the backend.

## Profile

The backend has no profile-update endpoint. The Profile page is therefore read-only and displays `UserResponseDto` data. Google profile completion is fully mapped through `/api/oauth-signup`.

## Caching

`src/api/client.js` attaches `Authorization: Bearer <jwt>` to authenticated requests and keeps a small in-memory TTL cache.

- Individual record: 5 minutes.
- User record list: 30 seconds.
- Writes invalidate the affected record/list cache.
- Logout/401 clears the session and cache.

No medical record data is stored in the old localStorage record index because that index has been removed.

## Development

Vite proxies both `/api` and `/oauth2` to `http://localhost:8080`.

`VITE_API_BASE_URL` may be set for a deployed backend. The backend's current OAuth success handler is hard-coded to redirect to `http://localhost:5173/oauth-success`, so production OAuth still requires the backend redirect URL to be changed server-side.
