import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Pill, ChevronRight } from "lucide-react";
import { useRecords } from "../../hooks/useRecords";
import { deriveMedicinesFromRecords } from "../../api/medications";
import { Spinner, ErrorBanner, EmptyState } from "../../components/ui";

export default function Medicines() {
  const { records, loading, error, refresh } = useRecords();
  const medicines = useMemo(() => deriveMedicinesFromRecords(records), [records]);

  return (
    <div>
      <div className="page-head">
        <div>
          <div className="page-title">Medicines</div>
          <div className="page-sub">Medicines mapped directly from your saved prescription records.</div>
        </div>
      </div>

      <ErrorBanner message={error} onRetry={refresh} />

      {loading ? (
        <Spinner label="Loading medicines…" />
      ) : medicines.length === 0 ? (
        <EmptyState
          icon="💊"
          title="No medicines yet"
          subtitle="Medicines will appear here automatically when a prescription record contains them."
        />
      ) : (
        <div className="medicine-grid">
          {medicines.map((m) => (
            <Link to={`/medicines/${encodeURIComponent(m.medicineName)}`} key={m.medicineName} className="medicine-tile">
              <div className="m-top">
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div className="icon-box icon-green" style={{ width: 32, height: 32 }}>
                    <Pill size={15} />
                  </div>
                  <div>
                    <div className="m-name">{m.medicineName}</div>
                    <div className="m-dose">
                      {[m.dosage, m.frequency, m.route].filter(Boolean).join(" · ") || "Prescription details not recorded"}
                    </div>
                  </div>
                </div>
                <ChevronRight size={16} color="#94a3b8" />
              </div>
              <div className="m-meta">{m.activeSalts || "Composition not recorded"}</div>
              <div className="m-meta">Seen in {m.sources.length} record{m.sources.length === 1 ? "" : "s"}</div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
