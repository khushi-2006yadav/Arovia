import { useAuth } from "../../context/AuthContext";

function initials(name = "") {
  return name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
}

function fmtDate(d) {
  if (!d) return "Not set";
  try {
    return new Date(d).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });
  } catch {
    return d;
  }
}

export default function Profile() {
  const { user } = useAuth();

  return (
    <div>
      <div className="page-head">
        <div>
          <div className="page-title">Profile</div>
          <div className="page-sub">Your account and health details returned by the backend.</div>
        </div>
      </div>

      <div className="ar-card">
        <div className="profile-header">
          <div className="profile-avatar">{initials(user?.name)}</div>
          <div>
            <div className="profile-name">{user?.name || "Account"}</div>
            <div className="profile-email">{user?.emailId || "—"}</div>
          </div>
        </div>

        <div className="detail-grid">
          <div className="detail-item"><div className="d-label">Date of Birth</div><div className="d-value">{fmtDate(user?.dob)}</div></div>
          <div className="detail-item"><div className="d-label">Gender</div><div className="d-value">{user?.gender || "Not set"}</div></div>
          <div className="detail-item"><div className="d-label">Blood Group</div><div className="d-value">{user?.bloodGroup?.replace("_", " ") || "Not set"}</div></div>
          <div className="detail-item"><div className="d-label">Weight</div><div className="d-value">{user?.weight != null ? `${user.weight} kg` : "Not set"}</div></div>
          <div className="detail-item"><div className="d-label">Height</div><div className="d-value">{user?.height != null ? `${user.height} cm` : "Not set"}</div></div>
          <div className="detail-item"><div className="d-label">Location</div><div className="d-value">{user?.location || "Not set"}</div></div>
        </div>
      </div>

      <div className="ar-card">
        <div className="ar-card-title" style={{ marginBottom: 10 }}>Chronic Conditions</div>
        {user?.pastChronicDiseases?.length ? user.pastChronicDiseases.map((d) => <span className="tag-pill" key={d}>{d}</span>) : <div style={{ fontSize: 12.5, color: "#94a3b8" }}>None recorded.</div>}

        <div className="ar-card-title" style={{ margin: "18px 0 10px" }}>Family History</div>
        {user?.familyDiseases?.length ? user.familyDiseases.map((d) => <span className="tag-pill" key={d}>{d}</span>) : <div style={{ fontSize: 12.5, color: "#94a3b8" }}>None recorded.</div>}

        <div className="upload-note" style={{ marginTop: 14 }}>
          The current backend exposes profile data through UserResponseDto but has no profile-update endpoint, so this page is intentionally read-only.
        </div>
      </div>
    </div>
  );
}
