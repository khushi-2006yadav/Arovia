import { useMemo } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { ArrowLeft, Pill, MapPin, ShieldCheck } from "lucide-react";
import { useRecords } from "../../hooks/useRecords";
import { findMedicine } from "../../api/medications";
import { useAuth } from "../../context/AuthContext";
import { BASE_URL } from "../../api/client";
import { Spinner } from "../../components/ui";

export default function MedicineDetail() {
  const { name } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { records, loading } = useRecords();

  const medicine = useMemo(() => findMedicine(records, name || ""), [records, name]);

  function findPharmacy() {
    const location = user?.location?.trim();
    if (!location) return;
    window.location.assign(`${BASE_URL}/api/medication/nearest-pharmacy?location=${encodeURIComponent(location)}`);
  }

  if (loading) return <Spinner label="Loading medicine…" />;

  if (!medicine) {
    return (
      <div>
        <button className="btn-ghost" onClick={() => navigate(-1)} style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <ArrowLeft size={15} /> Back
        </button>
        <div className="ar-card" style={{ marginTop: 16 }}>
          <div className="ar-card-title">Medicine not found</div>
          <p style={{ color: "#64748b", marginTop: 8 }}>This medicine is not present in the records returned for your account.</p>
          <Link to="/medicines" className="btn-teal" style={{ marginTop: 12 }}>Back to Medicines</Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <button className="btn-ghost" onClick={() => navigate(-1)} style={{ marginBottom: 14, display: "flex", alignItems: "center", gap: 6 }}>
        <ArrowLeft size={15} /> Back
      </button>

      <div className="page-head">
        <div>
          <div className="page-title">{medicine.medicineName}</div>
          <div className="page-sub">{[medicine.dosage, medicine.frequency, medicine.route].filter(Boolean).join(" · ") || "Prescription details"}</div>
        </div>
      </div>

      <div className="ar-card">
        <div className="ar-card-title" style={{ marginBottom: 12 }}><Pill size={16} /> Medicine Information</div>
        <div className="detail-grid">
          <div className="detail-item">
            <div className="d-label">Active Salts / Composition</div>
            <div className="d-value">{medicine.activeSalts || "Not available in backend record"}</div>
          </div>
          <div className="detail-item">
            <div className="d-label">Uses</div>
            <div className="d-value">{medicine.uses || "Not available in backend record"}</div>
          </div>
          <div className="detail-item">
            <div className="d-label">Side Effects</div>
            <div className="d-value">{medicine.sideEffects || "Not available in backend record"}</div>
          </div>
          <div className="detail-item">
            <div className="d-label">Latest Prescription</div>
            <div className="d-value">{medicine.latest?.recordDate || "—"}</div>
          </div>
        </div>
      </div>

      <div className="ar-card">
        <div className="ar-card-title" style={{ marginBottom: 10 }}>Prescription History</div>
        {medicine.sources.map((source) => (
          <Link key={`${source.recordId}-${source.recordDate}`} to={`/records/${source.recordId}`} className="suggestion-row" style={{ textDecoration: "none" }}>
            <span style={{ fontWeight: 700, color: "#0b2a4a" }}>{source.title}</span>
            <span style={{ marginLeft: "auto", fontSize: 12, color: "#64748b" }}>{source.recordDate}</span>
          </Link>
        ))}
      </div>

      <div className="ar-card">
        <div className="ar-card-title" style={{ marginBottom: 8 }}><MapPin size={16} /> Find a Nearby Jan Aushadhi Kendra</div>
        <p style={{ fontSize: 12.5, color: "#64748b", marginBottom: 12 }}>
          Uses the location saved in your Arovia profile and the backend's nearest-pharmacy redirect.
        </p>
        <button className="btn-teal" type="button" onClick={findPharmacy} disabled={!user?.location}>
          <MapPin size={15} /> {user?.location ? "Find Nearby Pharmacy" : "Add Location in Profile First"}
        </button>
        <div className="upload-note" style={{ marginTop: 12 }}>
          <ShieldCheck size={12} style={{ verticalAlign: -2 }} /> Medicine alternatives are not shown because the current backend does not expose an alternatives lookup API.
        </div>
      </div>
    </div>
  );
}
