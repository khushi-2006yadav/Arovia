import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { oauthSignin } from "../api/auth";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { ApiError } from "../api/client";

const OAUTH_TOKEN_KEY = "arovia_oauth_pending_token";

function profileComplete(user) {
  // Google OAuth creates the Patient before redirecting. The backend returns
  // null for health fields until the user completes them.
  return Boolean(user?.dob && user?.bloodGroup && user?.gender && user?.weight && user?.height && user?.location);
}

export default function OAuthSuccess() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { login } = useAuth();
  const toast = useToast();
  const [message, setMessage] = useState("Completing Google sign-in…");

  useEffect(() => {
    let cancelled = false;

    async function complete() {
      const token = params.get("token");
      if (!token) {
        navigate("/login", { replace: true });
        return;
      }

      sessionStorage.setItem(OAUTH_TOKEN_KEY, token);
      try {
        const data = await oauthSignin(token);
        if (cancelled) return;
        login(data);

        if (!profileComplete(data)) {
          toast.info("Google sign-in worked. Please complete your health profile.");
          navigate("/signup/complete", { replace: true, state: { googleToken: token } });
        } else {
          toast.success(`Welcome, ${data.name?.split(" ")[0] || "there"}!`);
          navigate("/dashboard", { replace: true });
        }
      } catch (err) {
        if (cancelled) return;
        setMessage(err instanceof ApiError ? err.message : "Google sign-in could not be completed.");
        sessionStorage.removeItem(OAUTH_TOKEN_KEY);
      }
    }

    complete();
    return () => { cancelled = true; };
  }, [params, navigate, login, toast]);

  return (
    <div className="login-page">
      <div className="login-body" style={{ justifyContent: "center" }}>
        <div className="login-card" style={{ maxWidth: 460 }}>
          <h2 className="login-title">{message}</h2>
          <p className="login-subtitle">Please wait while Arovia securely establishes your session.</p>
        </div>
      </div>
    </div>
  );
}

export { OAUTH_TOKEN_KEY };
