import { BASE_URL } from "../api/client";

/**
 * Uses the backend Spring Security OAuth2 flow.
 * The backend redirects to /oauth-success?token=<JWT> after Google auth.
 */
export default function GoogleAuthButton({ mode = "signin" }) {
  function startGoogleAuth() {
    // The backend creates/fetches the Patient and redirects back with its JWT.
    // mode is intentionally not sent: the backend's OAuth success handler
    // determines the account; the callback decides whether profile completion is needed.
    window.location.assign(`${BASE_URL}/oauth2/authorization/google`);
  }

  return (
    <button type="button" className="login-google-btn" onClick={startGoogleAuth}>
      <span className="login-google-icon">G</span>
      {mode === "signup" ? "Sign up with Google" : "Continue with Google"}
    </button>
  );
}
