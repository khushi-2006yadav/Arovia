
import { request } from "./client";

function normalizeKey(name = "") {
  return name.trim().toLowerCase();
}

export function deriveMedicinesFromRecords(records = []) {
  const byName = new Map();

  for (const record of records) {
    for (const medication of record.medications || []) {
      const medicine = medication.medicine || {};
      const name = medicine.medicineName || medication.medicineName;
      if (!name) continue;

      const key = normalizeKey(name);
      const existing = byName.get(key);
      const source = {
        recordId: record.id,
        title: record.title || record.recordType,
        recordDate: record.recordDate,
        dosage: medication.dosage,
        frequency: medication.frequency,
        route: medication.route,
        duration: medication.duration,
        instructions: medication.instructions,
        confidence: medication.confidence,
      };

      if (!existing) {
        byName.set(key, {
          medicineName: name,
          activeSalts: medicine.activeSalts,
          uses: medicine.uses,
          sideEffects: medicine.sideEffects,
          sources: [source],
          latest: source,
        });
      } else {
        existing.sources.push(source);
        if (!existing.latest || new Date(source.recordDate) > new Date(existing.latest.recordDate)) {
          existing.latest = source;
          existing.activeSalts = medicine.activeSalts || existing.activeSalts;
          existing.uses = medicine.uses || existing.uses;
          existing.sideEffects = medicine.sideEffects || existing.sideEffects;
        }
      }
    }
  }

  return [...byName.values()]
    .map((m) => ({
      ...m,
      dosage: m.latest?.dosage,
      frequency: m.latest?.frequency,
      route: m.latest?.route,
    }))
    .sort((a, b) => a.medicineName.localeCompare(b.medicineName));
}

export function findMedicine(records, medicineName) {
  const key = normalizeKey(medicineName);
  return deriveMedicinesFromRecords(records).find((m) => normalizeKey(m.medicineName) === key) || null;
}


export async function getMedicineInfo(medicineName, records = []) {
  return findMedicine(records, medicineName);
}

