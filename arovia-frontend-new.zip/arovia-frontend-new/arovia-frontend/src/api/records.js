import { request, invalidateCache } from "./client";

export async function addRecord(userId, medicalRecordDto) {
  if (!userId) throw new Error("Missing userId. Please sign in again.");

  const recordId = await request(`/api/record/${encodeURIComponent(userId)}/addRecords`, {
    method: "POST",
    body: medicalRecordDto,
  });

  invalidateCache(`records:${userId}`);
  if (recordId) invalidateCache(`record:${recordId}`);
  return recordId;
}

export async function fetchRecord(recordId, { skipCache = false } = {}) {
  if (!recordId) throw new Error("Missing record id.");
  return request(`/api/record/fetchRecord/${encodeURIComponent(recordId)}`, {
    cacheKey: `record:${recordId}`,
    cacheTtl: 5 * 60 * 1000,
    skipCache,
  });
}

export async function listRecords(userId, { skipCache = false } = {}) {
  if (!userId) return [];
  const data = await request(`/api/record/fetchRecords/${encodeURIComponent(userId)}`, {
    cacheKey: `records:${userId}`,
    cacheTtl: 30 * 1000,
    skipCache,
  });
  return Array.isArray(data) ? data : [];
}

export function recordCount(records = []) {
  return records.length;
}
