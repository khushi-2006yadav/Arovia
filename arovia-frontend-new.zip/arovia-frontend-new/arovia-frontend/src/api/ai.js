import { request } from "./client";

const STATUS_WEIGHT = { CRITICAL: 3, HIGH: 2, LOW: 2, UNKNOWN: 1, NORMAL: 0 };

export function buildRecordPreview(record) {
  const flagged = (record?.testResults || []).filter(
    (t) => t.status && t.status !== "NORMAL"
  );
  const meds = record?.medications || [];

  if (record?.recordType === "PRESCRIPTION") {
    const names = meds
      .map((m) => m.medicineName || m.medicine?.medicineName)
      .filter(Boolean);
    return {
      headline: names.length
        ? `${names.length} medicine${names.length > 1 ? "s" : ""} prescribed`
        : "Prescription recorded",
      detail: names.length
        ? `Includes ${names.join(", ")}. Review the prescription details below.`
        : "No medications were captured in this record.",
      source: "record-data",
    };
  }

  if (!flagged.length) {
    return {
      headline: "No flagged values in the saved record.",
      detail: "This is a display based on the status values saved in your record; it is not an AI diagnosis.",
      source: "record-data",
    };
  }

  const worst = [...flagged].sort(
    (a, b) => (STATUS_WEIGHT[b.status] || 0) - (STATUS_WEIGHT[a.status] || 0)
  )[0];

  return {
    headline: `${worst.testName} is ${String(worst.status).toLowerCase()}`,
    detail: `${worst.value ?? "—"} ${worst.unit || ""} · Reference: ${worst.referenceRange || "not provided"}. This is a record-data preview, not a diagnosis.`,
    source: "record-data",
  };
}


export async function summarizeRecord(record) {
  return buildRecordPreview(record);
}

export function buildTrends(records = []) {
  const byTest = new Map();
  for (const record of records) {
    for (const t of record.testResults || []) {
      if (t.value == null || !t.testName) continue;
      const list = byTest.get(t.testName) || [];
      list.push({
        date: record.recordDate,
        value: t.value,
        unit: t.unit,
        status: t.status,
        referenceRange: t.referenceRange,
      });
      byTest.set(t.testName, list);
    }
  }

  return [...byTest.entries()]
    .map(([testName, points]) => {
      points.sort((a, b) => new Date(a.date) - new Date(b.date));
      const latest = points[points.length - 1];
      const first = points[0];
      return {
        testName,
        points,
        latest,
        delta: points.length > 1 ? latest.value - first.value : 0,
      };
    })
    .sort((a, b) => a.testName.localeCompare(b.testName));
}

export function buildSuggestions(records = []) {
  const suggestions = [];
  for (const record of records) {
    for (const t of record.testResults || []) {
      if (t.status && t.status !== "NORMAL") {
        suggestions.push({
          testName: t.testName,
          status: t.status,
          value: t.value,
          unit: t.unit,
          referenceRange: t.referenceRange,
          recordId: record.id,
          recordDate: record.recordDate,
          recordTitle: record.title,
        });
      }
    }
  }
  return suggestions.sort((a, b) => new Date(b.recordDate) - new Date(a.recordDate));
}


export async function uploadRecordImage(payload) {
  return request("/api/ai/uploadRecord", {
    method: "POST",
    body: payload,
  });
}

export async function fetchHealthSuggestion(snapshot) {
  return request("/api/ai/fetchHealthSuggestion", {
    method: "POST",
    body: snapshot,
  });
}
