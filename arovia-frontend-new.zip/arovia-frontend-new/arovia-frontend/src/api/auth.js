import { request, setToken, invalidateCache } from "./client";

export async function signup(signupDto) {
  await request("/api/signup", { method: "POST", body: signupDto, auth: false });
}

function extractToken(data) {
  if (!data || typeof data !== "object") return null;
  return data.jwt || data.token || data.accessToken || data.access_token || null;
}

function finishAuth(data) {
  const token = extractToken(data);
  if (!token) throw new Error("The server signed in the account but did not return a JWT token.");
  setToken(token);
  invalidateCache();
  return data;
}

export async function signin({ emailId, password }) {
  const data = await request("/api/signin", {
    method: "POST",
    body: { emailId, password },
    auth: false,
  });
  return finishAuth(data);
}

export async function oauthSignin(googleIdToken) {
  const data = await request("/api/oauth-signin", {
    method: "POST",
    body: { token: googleIdToken },
    auth: false,
  });
  return finishAuth(data);
}

export async function oauthSignup(oAuthDto) {
  const data = await request("/api/oauth-signup", {
    method: "POST",
    body: oAuthDto,
    auth: false,
  });
  return finishAuth(data);
}

export function decodeJwtPayload(token) {
  try {
    const payload = token.split(".")[1];
    if (!payload) return null;
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(atob(normalized.padEnd(normalized.length + ((4 - normalized.length % 4) % 4), "=")));
  } catch {
    return null;
  }
}

export function getEmailFromJwt(token) {
  const payload = decodeJwtPayload(token);
  return payload?.sub || payload?.email || payload?.emailId || null;
}
